<template>
    <div class="c">
        <div class="company-text-slider">Comapny information</div>
        <img src="/images/main_page/sliders/slide1.jpg" class="img-fluid" height="300" />
    </div>
</template>
<style >
    .c{position: relative;}
    .company-text-slider{position:absolute;bottom: 15px;left: 0px;width:100%;text-align: center;font-size: 18px;font-weight: 700;}
</style>