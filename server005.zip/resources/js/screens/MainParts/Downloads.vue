<template>
    <div class="container mt-5 pt-5" >
        <div class="pt-5"></div>
        <div class="pt-5"></div>
        <div class="pt-5"></div>
       <h4 style="color:#192F60;text-align:center;font-family: 'Bebas Neue', cursive;font-size:30px;">Downloads</h4>
        <p style="font-family: 'Noto Sans', sans-serif;color:#192F60;text-align:center;font-size:16px;">Download now for free!</p>
        <div class="pt-2"></div>
        <div class="row container justify-content-center">
            <img src="/images/main_page/logo.png" class="img-fluid" style="width:130px;" alt="">
        </div>
        <div class="row pt-5 justify-content-center">
            <img src="/images/main_page/sliders/apple.png" style="height:55px;width:175px;cursor:pointer;" class="img-fluid" />
            <div style="width:10px;"></div>
            <img src="/images/main_page/sliders/google.png" style="height:55px;width:175px;cursor:pointer;" class="img-fluid" />
        </div>
        <div class="pt-5"></div>

        <div class="pt-5"></div>

    </div>
</template>
<script>
export default {
    
}
</script>
<style>

</style>