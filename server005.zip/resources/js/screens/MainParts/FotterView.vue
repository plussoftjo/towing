<template>
    <div class="pt-5">
    <ul class="footer-nav row justify-content-center" style="box-sizing: border-box; margin: 0px; padding: 20px 0px; list-style: none; border-bottom: 1px solid rgb(216, 216, 216); color: rgb(153, 153, 153); font-family: &quot;Noto Sans Japanese&quot;, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
  <li>&nbsp;</li>
  <li style="box-sizing: border-box; display: inline-block; font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-size: 15px; margin: 0px 8px;">
    <a href="#/company" style="box-sizing: border-box; background: transparent; color: rgb(9, 17, 35); text-decoration: none; opacity: 0.5; transition: all 0.3s ease 0s;">Company introduction</a>
  </li>
  <li>&nbsp;</li>
  <li style="box-sizing: border-box; display: inline-block; font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-size: 15px; margin: 0px 8px;">
    <a href="#/terms" style="box-sizing: border-box; background: transparent; color: rgb(9, 17, 35); text-decoration: none; opacity: 0.5; transition: all 0.3s ease 0s;">Terms of service</a>
  </li>
  <li>&nbsp;</li>
  <li style="box-sizing: border-box; display: inline-block; font-family: &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-size: 15px; margin: 0px 8px;">
    <a href="#/privacy" style="box-sizing: border-box; background: transparent; color: rgb(9, 17, 35); text-decoration: none; opacity: 0.5; transition: all 0.3s ease 0s;">privacy policy</a>
  </li>
</ul>
<div class="mt-3"></div>
<p style="text-align:center;">
  <img src="/images/main_page/logo.png" alt="JapanTaxi icon" class="footer-ico img-fluid" width="100 mt-3" style="box-sizing: border-box; border: 0px; color: rgb(153, 153, 153); font-family: &quot;Noto Sans Japanese&quot;, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
</p>
<p class="footer-title" style="box-sizing: border-box; margin: 15px 0px 5px; padding: 0px; font-size: 18px; line-height: 24px; color: rgb(153, 153, 153); font-family: &quot;Noto Sans Japanese&quot;, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
  <a href="https://ubrtowing.com/" style="box-sizing: border-box; background: transparent; color: rgb(9, 17, 35); text-decoration: none; opacity: 0.5; transition: all 0.3s ease 0s;" target="_blank">UBR-TOWING Co., Ltd.</a>
</p>
<p class="footer-address" style="box-sizing: border-box; margin: 0px 0px 15px; padding: 0px; font-size: 13px; line-height: 24px; color: rgb(153, 153, 153); font-family: &quot;Noto Sans Japanese&quot;, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
  <a href="" style="box-sizing: border-box; background: transparent; color: rgb(25, 47, 96); text-decoration: none; opacity: 0.5; transition: all 0.3s ease 0s;">USA</a>
</p>
<p class="footer-address" style="box-sizing: border-box; margin: 0px 0px 15px; padding: 0px; font-size: 13px; line-height: 24px; color: rgb(153, 153, 153); font-family: &quot;Noto Sans Japanese&quot;, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
  <br style="box-sizing: border-box;">for inquiries on&nbsp;how to use the "UBR-TOWING" application
  <a href="" target="_blank" style="box-sizing: border-box; background: transparent; color: rgb(25, 47, 96); text-decoration: none; opacity: 0.5; transition: all 0.3s ease 0s;"></a>
  <br style="box-sizing: border-box;">
</p>
<ul class="footer-sns row justify-content-center" style="box-sizing: border-box; margin: 0px 0px 15px; padding: 0px; list-style: none; color: rgb(153, 153, 153); font-family: &quot;Noto Sans Japanese&quot;, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">
  <li style="box-sizing: border-box; display: inline-block; margin: 10px 5px;">
    <a class="footer-sns-fb" href="" style="box-sizing: border-box; background: rgb(89, 173, 235); color: rgb(255, 255, 255); text-decoration: none; width: 44px; height: 44px; border-radius: 22px; display: inline-block; opacity: 0.2; transition: all 0.3s ease 0s; font-size: 20px;" target="_blank"><i class="fa fa-twitter"></i></a>
  </li>
  <li>&nbsp;</li>
  <li style="box-sizing: border-box; display: inline-block; margin: 10px 5px;">
    <a class="footer-sns-tw" href="" style="box-sizing: border-box; background: rgb(60, 91, 151); color: rgb(255, 255, 255); text-decoration: none; width: 44px; height: 44px; border-radius: 22px; display: inline-block; opacity: 0.2; transition: all 0.3s ease 0s; font-size: 20px;" target="_blank"><i class="fa fa-facebook"></i></a>
  </li>
</ul>
<p class="footer-copyright" style="box-sizing: border-box; margin: 0px 0px 15px; padding: 0px; font-size: 12px; line-height: 24px; color: rgb(153, 153, 153); font-family: &quot;Noto Sans Japanese&quot;, &quot;ヒラギノ角ゴ Pro W3&quot;, &quot;Hiragino Kaku Gothic Pro&quot;, メイリオ, Meiryo, Osaka, &quot;ＭＳ Ｐゴシック&quot;, &quot;MS PGothic&quot;, verdana, sans-serif; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: center; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;">© 2020 UBR-TOWING Co., Ltd.</p>
    </div>
</template>