<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class driver_images extends Model
{
    protected $fillable=['user_id','image','type'];
}
